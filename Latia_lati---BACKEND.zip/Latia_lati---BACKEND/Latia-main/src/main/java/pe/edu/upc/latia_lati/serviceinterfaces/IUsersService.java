package pe.edu.upc.latia_lati.serviceinterfaces;

import java.util.List;
import java.util.Optional;

import pe.edu.upc.latia_lati.entities.Users;

public interface IUsersService {
    public void insert(Users user);
    public List<Users> list();
    public void update(Users user);
    public void delete(Long idUser);
    public Optional<Users> listId(Long id);
    public Optional<Users> findByEmail(String email);

    // Consultas adicionales; los métodos CRUD de main se conservan.
    public List<Users> obtenerPorEstado(Boolean active);
    public List<Object[]> cantidadPerfilesPorUsuario();

}
