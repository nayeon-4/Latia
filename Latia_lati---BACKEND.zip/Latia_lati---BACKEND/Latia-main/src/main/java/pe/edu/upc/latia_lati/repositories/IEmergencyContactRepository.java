package pe.edu.upc.latia_lati.repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import pe.edu.upc.latia_lati.entities.EmergencyContact;
import pe.edu.upc.latia_lati.entities.HealthProfile;

import java.util.List;

@Repository
public interface IEmergencyContactRepository extends JpaRepository<EmergencyContact, Long> {
    // HU68 (simple): contactos marcados como principales
    public List<EmergencyContact> findByPrimaryContactTrue();

    // HU69 (join): ficha de emergencia de cada perfil de salud activo con su contacto principal
    // El nombre del paciente sale de users (dueño del perfil)
@Query(value = "SELECT hp.id_health_profile, u.first_name, u.last_name, hp.blood_type, ec.name, ec.phone, ec.relationship " +
        "FROM health_profiles hp " +
        "INNER JOIN users u " +
        "ON u.id_user = hp.id_owner_user " +
        "INNER JOIN emergency_contacts ec " +
        "ON ec.id_health_profile = hp.id_health_profile " +
        "WHERE ec.primary_contact = true AND hp.active = true " +
        "ORDER BY u.last_name, u.first_name",
        nativeQuery = true)
public List<Object[]> getEmergencyCards();
}